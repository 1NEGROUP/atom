# Atom Support

If you're looking for support for Atom there are a lot of options, check out:

* User Documentation &mdash; [The Atom Flight Manual](https://flight-manual.atom.io)
* Developer Documentation &mdash; [Atom API Documentation](https://atom.io/docs/api/latest)
* Message Board &mdash; [Github Discussions, the official Atom message board](https://github.com/atom/atom/discussions)

On Atoms Github Discussions board, there are a bunch of helpful community members that should be willing to point you in the right direction.
