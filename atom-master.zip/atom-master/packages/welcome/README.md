## Welcome package

Opens a welcome editor with helpful information the very first time Atom is opened and the usage statistics opt-in.
